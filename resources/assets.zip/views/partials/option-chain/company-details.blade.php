<div id="filter-options" data-post-id="{{get_the_ID()}}" data-symbol="{{@$symbol}}" data-inst-name="{{@$inst_name}}" data-fincode="{{$fin_code}}" data-apiexchg="{{$api_exchg}}" data-details="" ></div>
<div class="section-companyprice bg-light section-padding mb-5"  id="company-stock-live">
</div>
