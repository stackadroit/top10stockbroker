<div class="page-header">
  <h1 class="font-weight-bold mt-4">{!! App::title() !!}</h1>
</div>
