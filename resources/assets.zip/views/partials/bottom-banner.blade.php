<div style="margin: 0px auto; text-align: center;">
{!! do_shortcode('[LB_BANNER_DISPLAY_SHORTCODE url="'.get_the_permalink().'" type="4" is_mobile="'.$is_mobile.'"]') !!}
</div>