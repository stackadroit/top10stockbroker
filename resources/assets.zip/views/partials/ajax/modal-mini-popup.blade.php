<div class="container-fluid py-4">
  <h4  style="text-align: center;">{{$head_title}}</h4>
  {!! do_shortcode($do_contactform) !!}
  <p class="mini mb-0"  style="text-align: center;">
    {{$btm_content}}
  </p>
</div>