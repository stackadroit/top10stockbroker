<div class="section-companydetails pb-5">
  <div class="row">
    <div class="col-md-12">
      <h1 class="text-orange">
      {{@$get_detail_page['main_section_title']}}</h1>
      <p>{{@$get_detail_page['main_section_content']}}</p>
    </div>
  </div>
</div>
<div class="section_corporateact pb-5" id="mostActiveStockFuturesDetail" data-page-id={{get_the_ID()}}>
</div>