<div id="marketRadar">
	<button class="drop-btn" id="arrow-button-widget" aria-label="Button Widget"><i class="fas fa-angle-down"></i></button>
	<div class="widget-rp py-1 w-10">
		<div id="widget-first" class="treadmill">
		</div>
	</div>
	<div class="widget-rp py-1 second-rp w-10">
		<div id="widget-second" class="treadmill overflow-hidden px-2">
		</div>
	</div>
</div>