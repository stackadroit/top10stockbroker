<div class="container-fluid py-4">
	{!! do_shortcode('[LB_NOTIFICATION_BANNER_SHORTCODE url="'.get_the_permalink().'" type="2"]') !!}
    <div class="row">
      <div class="col-md-12 p-4">
      	<section id="list-slider-modal" class="icon-slider slider" data-id="19870" ></section>
      </div>
  </div>
</div>