<div class="section-companydetails pb-5">
  <div class="row">
    <div class="col-md-12">
      <h1 class="text-orange">{{@$get_detail_page['main_h1_title']}}</h1>
      <p>{{@$get_detail_page['main_para_content']}}</p>
    </div>
  </div>
</div>
<input type="hidden" id="ActiveInstName" value="{{@$get_detail_page['InstName']}}" data-page-id="{{@$get_detail_page['pageID']}}" data-page-size="{{@$get_detail_page['PageSize']}}">
<div class="section_corporateact pb-5" id="mostActiveStockIndexOptionDetail">
</div>