<div class="section-companydetails pb-5">
  <div class="row">
    <div class="col-md-12">
      <h1 class="text-orange">{{@$get_detail_page['main_h1_title']}}</h1>
      <p>{{@$get_detail_page['main_para_content']}}</p>
    </div>
  </div>
</div>
<input type="hidden" id="pageID" value="{{@$get_detail_page['pageID']}}">
<div class="section_corporateact pb-5 putCallRatioDetails" id="putCallRatioDetails">
</div>