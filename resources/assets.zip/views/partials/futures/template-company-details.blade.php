<div class="section-companyprice bg-light section-padding mb-5"  id="company-stock-live">
    <div id="filter-options" data-post-id="{{get_the_ID()}}" data-inst-name="{{$inst_name}}" data-symbol="{{$symbol}}"></div>
</div>