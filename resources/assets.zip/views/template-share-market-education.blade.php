{{--
  Template Name: Share Market Education
--}}

@extends('layouts.app-full')

@section('content')
  @while(have_posts()) @php the_post() @endphp
    @include('partials.page-header')
    @include('partials.content-page')
  @endwhile
@endsection
