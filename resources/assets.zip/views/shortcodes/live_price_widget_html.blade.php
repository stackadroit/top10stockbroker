<div class="">
	<div id="marketRadar">
    <button className="drop-btn" id="arrow-button-widget" aria-label="Button Widget"><i className="fa fa-angle-up"></i></button>
		<div class="widget-rp">
			<div id="widget-first" class="treadmill">
			</div>
		</div>
		<div class="widget-rp second-rp">
			<div id="widget-second" class="treadmill">
			</div>
		</div>
	</div>
</div>    