<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> EBIT (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="827222" id="eb_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Tax Rate (%)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="12.7" id="tr2_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Depriciation & Amortization (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="73999" id="da2_id"> 
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Changes in Working Capital (Rs.) * </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="261817" id="cw_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Capital Expenditure (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="368811" id="cex_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">  Free Cashflow to Equity</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control"   type="text" value="165535.806" id="fc_id" readonly>
        </div>
    </div> 
</section> 