<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>  Net Income (Rs.)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control" type="number" value="50000000" id="net_income_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>  Dividend on Preffered Stocks (Rs.) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control" type="number" value="200000" id="div_stock_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Outstanding Shares  </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control" type="number" value="15000000" id="ot_share_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Diluted Shares* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control" type="number" value="300000" id="dilute_share_id" >
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Diluted EPS (Rs.)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">  
            <input class="form-control" type="text" value="" id="deps_id" readonly>
        </div>
    </div> 
</section>  
