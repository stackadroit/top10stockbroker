<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Cash Flow of a Period*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="300" id="m_amount_id1">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Rate of Return (%) * </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="7" id="rate_id1">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Time / Period* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="3" id="time_id1">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Present Value</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="367.5129" id="result_id1" readonly>
        </div>
    </div> 
</section> 