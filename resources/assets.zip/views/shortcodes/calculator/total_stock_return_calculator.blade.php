<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Initial Stock Price (Rs.)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="700"  id="isp_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Ending Stock Price (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="732" id="esp_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Dividend Earned per Share (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="17" id="deps1_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Total Stock Return (%) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control" type="text" value="7" id="tsr1_id" readonly>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Total Stock Return per Share (Rs.) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="49" id="tsr2_id" readonly>
        </div>
    </div> 
</section> 