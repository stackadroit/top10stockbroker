<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Interest or Coupon Payment (Rs.)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="300"  id="interest_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Face Value of Bond (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="2500" id="face_value_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Price of Bond (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="2189"  id="price_of_bond_id" >
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Time / Period of Maturity* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="6" id="maturity_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Yield of Maturity (%)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="5.59" id="ram_id" readonly>
        </div>
    </div> 
</section>