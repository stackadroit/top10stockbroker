<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Monthly SIP(Rs)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="number" id="m_amount_id" value="2000"> 
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Expected Interest Rate*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control" type="number" id="rate_id" value="12">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Time(Years)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control" type="number" id="time_id" value="10">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt"> Intrinsic Value per share</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="number" value="464678" id="result_id">
        </div>
    </div>    
</section>  
