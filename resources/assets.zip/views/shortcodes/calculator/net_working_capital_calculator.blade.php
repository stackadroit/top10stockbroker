<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Current Assets (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control"  id="ca2_id" value="700000">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Current Liabilities (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" id="cl2_id" value="400000">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Net Working Capital (Rs.)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control" type="text" value="300000" id="nwc_id" readonly>
        </div>
    </div> 
</section> 