<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Net Income (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control" type="number" value="" id="net_income_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Preferred Dividends (Rs.)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control"  type="number" value="" id="preferred_div_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Weighted Avg. Outstanding Shares* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control" type="number" value="" id="waos_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Earnings per Share (Rs.)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">  
            <input class="form-control" type="text" value="" id="eps_id" readonly>
        </div>
    </div> 
</section>  
