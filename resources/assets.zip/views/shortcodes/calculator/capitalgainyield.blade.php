<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>  Initial Stock Price (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control"  type="number" value="100" id="initial_stock_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Ending Stock Price (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control"   type="number" value="110" id="end_stock_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Capital Gains Yield (%)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control"  type="text" value="10.0" id="cgy_id" readonly>
        </div>
    </div> 
</section>  
