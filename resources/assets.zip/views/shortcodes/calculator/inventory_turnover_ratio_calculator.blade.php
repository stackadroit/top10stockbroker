<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Cost of Goods Sold (Rs.) * </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" id="cgs_id" value="1000000">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Avg. Inventory (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
         <input type="number" class="form-control"  id="ai_id" value="300000">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt"> Inventory Turnover Ratio</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="3.33" id="itr_id" readonly>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt"> Days Inventory</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="109.5" id="dis_id" readonly>
        </div>
    </div> 
</section> 