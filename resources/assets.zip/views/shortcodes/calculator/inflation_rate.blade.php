<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Initial Consumer Price Index* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="210" id="icpi_id" >
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Ending Consumer Price Index* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
         <input type="number" class="form-control" value="217" id="ecpi_id">
        </div>    
        <hr class="hori col-md-12">   
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Inflation Rate (%) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="3.33" id="ir_id" readonly>
        </div>
    </div>   
</section> 