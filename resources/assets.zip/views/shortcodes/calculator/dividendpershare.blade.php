<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Sum of Dividend Paid Over a Year (Rs.)*  </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="number" value="" id="sum_dividend_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Special, One time Dividends paid in the Period (Rs.)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="number" value="" id="onetime_div_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Number of Outstanding Shares* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control" type="number" value="" id="nos_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Dividend per Share (Rs.)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">  
            <input class="form-control" type="text" value="" id="dps_id" readonly>
        </div> 
    </div> 
</section>  
