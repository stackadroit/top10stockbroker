<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Current Assets (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="100000" id="ca_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Inventory (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control"  value="20000" id="i_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Current Liabilities (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="60000" id="cl_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Quick Ratio </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control" type="text" value="1.33" id="qr_id" readonly>
        </div>
    </div> 
</section> 