<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Sales Revenue (Rs.) * </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="400000"  id="sr4_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> COGS (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="129288" id="cog_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt"> Gross Profit Margin (%)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control" type="text" value="67.7" id="gp_id" readonly>
        </div>
    </div> 
</section> 