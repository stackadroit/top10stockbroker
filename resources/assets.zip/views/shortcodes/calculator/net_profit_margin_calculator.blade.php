<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Net Income (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" id="ni1_id" value="250000">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Sales Revenue (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
         <input type="number" class="form-control" id="srrs_id" value="4000000">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt"> Net Profit Margin (%)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="6.25" id="np_id" readonly>
        </div>
    </div> 
</section> 