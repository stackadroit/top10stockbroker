<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Rate of Return (%)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="6" id="ror1_id" name="ror[]">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Rate of Return (%)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="3" id="ror2_id" name="ror[]">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Rate of Return (%)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="4" id="ror3_id" name="ror[]">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Rate of Return (%)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="8" id="ror4_id" name="ror[]">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Rate of Return (%)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="9" id="ror5_id" name="ror[]">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Rate of Return (%)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="12" id="ror6_id" name="ror[]">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Rate of Return (%)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="11" id="ror7_id" name="ror[]">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Number of Periods / Time*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="7" id="period_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt"> Holding Period Return (%)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control" type="text" value="66.2" id="hpr_id" readonly>
        </div>
    </div> 
</section> 