<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Estimated Dividend for the Next Period (Rs.)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="8973828" id="edfnp_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Required Rate of Retun (%) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="7" id="rrfr_id" >
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Growth Rate (%)  </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="3" id="gr1_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">PV of Stock with Contant Growth (Rs.) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control" type="text" value="224345700.00" id="pvosc_id" readonly>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt"> PV of Stock per Share (Rs.)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control" type="text" value="25.00" id="pvspr_id" readonly>
        </div>
    </div> 
</section>