<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Net Income (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="821717" id="ni_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Dividends (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
         <input type="number" class="form-control" value="637278" id="d_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Retention Ratio (%)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="22.4" id="rr_id" readonly>
        </div>
    </div> 
</section> 