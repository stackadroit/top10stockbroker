<h2>{{ $title }}</h2>
 <section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Total Earnings (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="300000" id="te_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Initial Investment (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
         <input type="number" class="form-control"  value="250000" id="iin_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Return on Investment (%) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="roi_id form-control" type="text" value="20.00" id="roi_id" readonly>
        </div>

    </div> 
</section> 