<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Estimated Dividend for the Next Period (Rs.)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="759000" id="edf_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Required Rate of Retun (%) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="5" id="rate_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">PV of Stock with Zero Growth (Rs.) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control"   type="text" value="15180000" id="pszg_id" readonly>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt"> PV of Stock per Share (Rs.)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control"   type="text" value="20" id="psp_id" readonly>
        </div>
    </div> 
</section> 