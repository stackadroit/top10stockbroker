<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
  <div class="cinner bdrtp form-row shortcode-bg">
      <div class="col-md-6 mt-1 mt-sm-2">
        <span> Total Assets (Rs.)* </span>
      </div>
      <div class="col-md-6 mt-1 mt-sm-2">
        <input type="number" class="form-control" value="800000" id="tars_id">
      </div>
      <div class="col-md-6 mt-1 mt-sm-2">
        <span>Sales per Share (Rs.)* </span>
      </div>
      <div class="col-md-6 mt-1 mt-sm-2">
        <input type="number" class="form-control" value="200000" id="srr_id">
      </div>
      <hr class="hori col-md-12">
      <div class="col-md-6 mt-1 mt-sm-2">
        <span class="pad-rt"> Assets to Sales Ratio </span>
      </div>
      <div class="col-md-6 mt-1 mt-sm-2"> 
        <input  class="form-control" type="text" value="4.00" id="asr_id" readonly>
      </div>
  </div> 
</section> 