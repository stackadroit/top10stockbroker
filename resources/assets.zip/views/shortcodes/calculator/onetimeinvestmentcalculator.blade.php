<section class="calculator-data">
   <h2>{{ $title }}</h2>
   <div><span>monthly amount</span><input type="text" id="m_amount_id2" value=""></div>
   <div><span>interest</span><input type="text" id="rate_id2" value="" ></div>
   <div><span>time</span><input type="text" id="time_id2" value="" ></div>
   <div><input type="text" value="" id="result_id2"></div>
</section>