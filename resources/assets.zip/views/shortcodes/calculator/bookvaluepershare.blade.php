<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>  Total Shareholders Equity (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="10000000" id="shareholder_equity_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Preferred Equity (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="3000000" id="prefer_equity_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Total Outstanding Shares* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control"  value="700000" id="to_share_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Book Value per Share or BVPS (Rs.) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="10" id="bvps_id" readonly>
        </div>  
    </div>
</section> 
