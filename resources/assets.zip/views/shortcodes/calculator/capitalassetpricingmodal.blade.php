<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>  Risk Free Rate  (%)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="10" id="risk_free_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Beta* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="2" id="beta_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Return on the Market (%)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="12" id="return_mkt_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt"> Expected Return (%)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="14" id="er_id" readonly>
        </div>
    </div> 
</section>  
