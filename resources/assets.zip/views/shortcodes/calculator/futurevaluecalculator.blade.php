<section class="calculator-data">
   <h2>{{ $title }}</h2>
   <span>monthly amount</span>
   <div><input type="text" id="m_amount_id1" value=""></div>
   <div><span>interest</span>><input type="text" id="rate_id1" value=""></div>
   <div><span>time</span><input type="text" id="time_id1" value=""></div>
   <div><input type="text" value="" id="result_id1"> </div> 
</section>