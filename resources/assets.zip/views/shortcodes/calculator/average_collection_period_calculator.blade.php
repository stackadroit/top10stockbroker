<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row  shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Sales Revenue (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="500000"  id="sr3_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Avg. Account Receivables (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="30000" id="aar_id" >
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt"> Average Collection Period (days)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control" type="text" value="21.90" id="acpd_id" readonly>
        </div>
    </div> 
</section>