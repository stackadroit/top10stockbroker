<h2>{{ $title }}</h2> 
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Future Outflows (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="30000" id="fo1_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Initial Investment (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control"  value="100000" id="iit_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Discount Rate (%)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="10" id="dr_id" >
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Time / Period (Yrs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="4" id="tp_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Profitability Index (%) </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="pp1_id form-control" type="text" value="0.978232361" id="pi1_id" readonly>
        </div>
    </div> 
</section> 