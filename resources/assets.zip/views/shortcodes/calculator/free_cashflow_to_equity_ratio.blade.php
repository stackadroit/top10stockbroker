<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Net Income (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="168000" id="ni_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Depriciation & Amortization (Rs.) * </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="150000" id="da1_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>  Working Capital (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="75000"  id="wc_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Capital Expenditure (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="300000" id="ce1_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Net Borrowings (Rs.)* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="72000" id="nb_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">  Free Cashflow to Equity</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input  class="form-control"   type="text" value="15000" id="fcte_id" readonly>
        </div>
    </div> 
</section> 