<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Dividends per Share for the Period (Rs.)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control" type="number" value="" id="dividend_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Initial Share Price for the Period (Rs.)*</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input class="form-control" type="number" value="" id="share_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Dividend Yield (%)</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">  
            <input class="form-control" type="text" value="" id="dy_id" readonly>
        </div>
    </div> 
</section>   
