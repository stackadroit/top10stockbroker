<h2>{{ $title }}</h2>
<section class="couter shotcodwraper">       
    <div class="cinner bdrtp form-row shortcode-bg">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span> Ask Price of a Stock* </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="500" id="ask_prc_id">
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <span>Rate of Interest (%)*  </span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2">
            <input type="number" class="form-control" value="321" id="bid_prc_id">
        </div>
        <hr class="hori col-md-12">
        <div class="col-md-6 mt-1 mt-sm-2">
            <span class="pad-rt">Bid Ask Spread</span>
        </div>
        <div class="col-md-6 mt-1 mt-sm-2"> 
            <input class="form-control" type="text" value="179" id="bid_ask_id" readonly>
        </div>
    </div> 
</section> 