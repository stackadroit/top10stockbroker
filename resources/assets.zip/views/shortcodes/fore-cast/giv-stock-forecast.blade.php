<div data-id="{{@$id}}" data-calculate-button="{{ @$calculate_button }}" id="giv-stock-forecast-calculator">
	<div id="givForeCastCalculator" class="tab-pane" data-fincode="{{@$fin_code}}" data-filter="{{@$stock_filter}}">
    </div>
</div>