    <div class="selectbrockerdiv">
            <div class="broker-title">
                <h4>Search {{$city}} Pincode Here</h4>
            </div>
        <div class="row">
            <div class="selectbrkerdata col-sm-6">
            <input class="search-pincode-input" type="text" name="spin" value="" placeholder="Search pincode"/>
            </div>
            <div class="selectbrkerdata col-sm-6">
                <button type="button" class="comlink btn btn-primary"  id="location-search_id">Submit</button>
                &nbsp;&nbsp;
                 <button type="button" class="comlink btn btn-primary"  id="location-search_clear">Clear</button> 
            </div>
    </div>
</div>