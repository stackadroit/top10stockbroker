<section id="list-slider" class="icon-slider slider" data-id="{{ $id }}" >
</section>